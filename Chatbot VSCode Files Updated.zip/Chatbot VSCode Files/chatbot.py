import streamlit as st
import pickle
import random
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import string
# Sample dataset
data = {
    "greetings": {
        "questions": ["Hi", "Hello", "Good morning", "Good evening"],
        "responses": ["Hello!", "Hi there!", "Greetings!", "Good day!"]
    },
    "farewells": {
        "questions": ["Bye", "Goodbye", "See you later", "Take care"],
        "responses": ["Goodbye!", "See you later!", "Take care!", "Bye!"]
    },
    "thanks": {
        "questions": ["Thank you", "Thanks", "Much appreciated"],
        "responses": ["You're welcome!", "No problem!", "Glad to help!"]
    }
}

def preprocess(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in stopwords.words('english')]
    return ' '.join(tokens)
# Load the model
with open('chatbot_model.pkl', 'rb') as f:
    model = pickle.load(f)

def get_response(user_input):
    user_input = preprocess(user_input)
    predicted_label = model.predict([user_input])[0]
    response = random.choice(data[predicted_label]['responses'])
    return response

st.title("Simple Chatbot")

user_input = st.text_input("You: ", "Hello, how are you?")
if st.button("Send"):
    response = get_response(user_input)
    st.text(f"Chatbot: {response}")